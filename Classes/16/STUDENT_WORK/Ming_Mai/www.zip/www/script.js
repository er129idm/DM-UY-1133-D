function setup() {
  
    noCanvas();

    let txt = createDiv('despair!');
    txt.position(random(windowWidth), random(windowHeight));
  }
  
  function ho() {
    document.body.style.backgroundColor = "red";
  }